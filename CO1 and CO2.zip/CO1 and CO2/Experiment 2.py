#Experiment 2
#A program to find the area and perimeter of a circle.

#Declaring a variable to which the user inputs the radius of the circle
Rds= int(input("Enter the radius of the circle : "))

#Calculations
AR=3.14*Rds*Rds     #Area of a circle= pi * radius^2
PR=3.14*2*Rds       #Perimeter of a circle= 2 * pi * radius

#Printing the results:
print("Area of the circle = ",AR)
print("Perimeter of the circle = ",PR)
