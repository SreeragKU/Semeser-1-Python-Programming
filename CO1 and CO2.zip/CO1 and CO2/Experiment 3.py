#Experiment 3:
#A program to convert Celsius to Fahrenheit:

#Declaring a variable to which the user inputs the temperature in Celsius:
Cels =int(input("Enter the temperature in Celsius : "))

#Calculation:
Frht= 9/5*Cels+32      #Fahrenheit = 9/5 * Celsius + 32

#Printing the result:
print("The temperature,",Cels,"C = ",Frht,"F")
print("(Where C is Celsius and F is Fahrenheit)")
