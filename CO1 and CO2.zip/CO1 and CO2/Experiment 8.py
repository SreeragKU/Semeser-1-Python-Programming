#Experiment 8:
#A program to find the volume of a cylinder:

#Declaring a variable to which the user inputs the radius of the cylinder:
Rds=int(input("Enter the radius of the cylinder : "))

#Declaring a second variable to which the user inputs the height of the cylinder:
Hght=int(input("Enter the height of the cylinder : "))

#Calculation:
Vlum=3.14*Rds*Rds*Hght      #Volume of a cylinder= pi * radius^2 * height

#Printing the result:
print("The volume of cylinder = ",Vlum)