#Experiment 7:
#A program to enter the distance in feet and convert to inches

#Declaring a variable to which the user inputs the distance in foots:
Fts=int(input("The length in feet (ft)= "))

#Calculation:
Inchs= 12*Fts    #1 foot= 12 inches

#Printing the result:
print("The length,",Fts," ft = ",Inchs, "inches")
